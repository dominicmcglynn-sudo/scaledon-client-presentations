---
name: client-presentation
description: This skill should be used when creating shareable HTML presentations for ScaledOn clients. It generates professional, branded presentations using ScaledOn's visual identity and publishes them to a password-protected URL via GitHub and Cloudflare Pages. Use when Bogdan or the team needs to share strategy documents, budget recommendations, performance reports, or proposals with clients in a polished, web-based format.
tier: T2
---

# Client Presentation Skill

Create and publish professional HTML presentations for ScaledOn clients with automatic deployment to a shareable URL.

## When to Use

- Client strategy presentations (ads, content, growth)
- Budget recommendations and proposals
- Performance reports and dashboards
- Any document that needs to be shared externally as a polished web page

## Outputs

- **Local HTML file** in a working folder
- **Published URL**: `https://scaledon-client-presentations.pages.dev/{client-slug}/`
- **Password protected** (credentials: `scaledon` / `daphnis2026`)

## Workflow

### 1. Gather Inputs

Required information before starting:
- **Client name** (display name for header)
- **Client slug** (lowercase, hyphens, e.g., `daphnis`, `under-the-weather`)
- **Presentation title** (e.g., "Amazon Advertising Strategy")
- **Content sections** (what needs to be communicated)
- **Supporting images** (screenshots, charts, proof points)

### 2. Create Presentation

1. Create a working folder:
   ```
   /tmp/{client-slug}/
   ├── index.html
   └── images/
       └── (any screenshots or images)
   ```

2. Use the HTML template from `assets/templates/presentation-template.html` as the base structure

3. Build content using components from `references/component-library.md`:
   - `.context-section` - Introduction/background
   - `.metrics-grid` - KPI cards
   - `.highlight-box` - Key value propositions
   - `.alert-box` - Problems/warnings
   - `.screenshot-section` - Annotated images
   - `.proof-section` - Results/proof points
   - `.strategy-section` - Main content
   - `.budget-table` - Pricing/budget options
   - `.checklist-box` - Action items
   - `.next-steps` - CTA section

4. Copy any supporting images to `images/` subfolder

### 3. Publish

Run the publish script:
```bash
scripts/publish.sh {client-slug} /tmp/{client-slug}
```

This will:
- Copy files to the GitHub repo
- Commit and push changes
- Cloudflare Pages auto-deploys

**Live URL**: `https://scaledon-client-presentations.pages.dev/{client-slug}/`

## Repository Structure

The presentations are stored in:
```
/Users/domscaledon/Documents/GitHub Amazon Branch Nov/Amazon Dept/client-presentations/
├── README.md
├── functions/
│   └── _middleware.js    # Basic auth (password protection)
├── daphnis/
│   ├── index.html
│   └── images/
├── {other-clients}/
│   └── ...
```

## Presentation Sections (Common Patterns)

### Strategy/Proposal Presentations
1. Context section - Where the client is today
2. Metrics grid - Key numbers
3. Alert box - The problem
4. Screenshot section - Visual evidence
5. Highlight box - The opportunity
6. Info card grid - Strategy explanation
7. Proof section - Why it works (results from other clients)
8. Budget table - Investment options
9. Next steps - CTA

### Performance Reports
1. Header with date range
2. Metrics grid - KPIs
3. Highlight box - Key wins
4. Charts (if needed, use Chart.js)
5. Strategy section - Analysis
6. Next steps - Recommendations

## Brand Guidelines

All presentations MUST use ScaledOn brand colors:
- Primary gradient: `#f79253` → `#ed4691` (orange to pink)
- Footer gradient: `#3f56cd` → `#ed4691` (blue to pink)
- Font: Quicksand (Google Fonts)

DO NOT customize colors per client. Consistent ScaledOn branding across all presentations.

## Evidence Requirements (T2)

Since this skill produces client-facing content:
- All metrics/numbers must come from verified sources (Seller Central, ad reports)
- Screenshots should be actual client data where possible
- Proof points from other clients must be anonymized or have permission

## Resources

### scripts/
- `publish.sh` - Publishes a presentation folder to GitHub/Cloudflare

### references/
- `component-library.md` - HTML/CSS component reference for building presentations

### assets/
- `templates/presentation-template.html` - Base HTML template with all CSS

## Handoff

After publishing, provide:
1. **URL**: `https://scaledon-client-presentations.pages.dev/{client-slug}/`
2. **Credentials**: Username `scaledon`, Password `daphnis2026`
3. **Note**: Bogdan can share this link directly with the client
