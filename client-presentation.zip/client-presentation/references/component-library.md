# Client Presentation Component Library

Quick reference for available HTML components in client presentations.

## Container Structure

```html
<div class="dashboard-container">
    <div class="header">
        <h1>Client Name</h1>
        <p>Presentation Title | Date</p>
    </div>
    <div class="main-content">
        <!-- Content sections here -->
    </div>
    <div class="footer">
        <p>Prepared by ScaledOn | Footer Text | Date</p>
    </div>
</div>
```

## Content Sections

### Context Section (Left-bordered intro)
```html
<div class="context-section">
    <h2>Section Title</h2>
    <p>Content with <strong>highlighted text</strong>.</p>
</div>
```

### Metrics Grid (KPI Cards)
```html
<h2 class="section-title">Metrics Title</h2>
<div class="metrics-grid">
    <div class="metric-card">
        <div class="metric-title">METRIC NAME</div>
        <div class="metric-value">$150K</div>
        <div class="metric-change positive">+15% YoY</div>
    </div>
    <!-- More cards... -->
</div>
```
Badge classes: `.positive` (green), `.negative` (red), `.neutral` (gray)

### Highlight Box (Gradient callout)
```html
<div class="highlight-box">
    <h2>The Opportunity</h2>
    <p>Key message or value proposition.</p>
</div>
```

### Alert Box (Yellow warning)
```html
<div class="alert-box">
    <h3>Warning Title</h3>
    <p>Alert message content.</p>
</div>
```

### Screenshot Section (Annotated images)
```html
<div class="screenshot-section">
    <h3>Section Title</h3>
    <div class="screenshot-container">
        <img src="images/screenshot.png" alt="Description">
        <div class="screenshot-caption">
            <strong>Caption Title</strong>
            Caption description text.
        </div>
    </div>
</div>
```

### Proof Section (Green success box)
```html
<div class="proof-section">
    <h3>Results Title</h3>
    <img src="images/results.png" alt="Results">
    <p>Explanation of the results.</p>
    <div class="proof-metrics">
        <div class="proof-metric">
            <div class="value">$12.8K</div>
            <div class="label">Ad Spend</div>
        </div>
        <!-- More metrics... -->
    </div>
</div>
```

### Strategy Section (White content box)
```html
<div class="strategy-section">
    <h2 class="section-title">Strategy Title</h2>
    <p>Introduction text.</p>
    <ul>
        <li><strong>Point one:</strong> Description</li>
        <li><strong>Point two:</strong> Description</li>
    </ul>
</div>
```

### Budget Table
```html
<div class="strategy-section">
    <h2 class="section-title">Budget Recommendations</h2>
    <table class="budget-table">
        <thead>
            <tr>
                <th>Plan</th>
                <th>Monthly Budget</th>
                <th>Focus</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><strong>Conservative</strong></td>
                <td>$500/mo</td>
                <td>Basic coverage</td>
            </tr>
            <tr class="recommended-row">
                <td><strong>Recommended</strong></td>
                <td>$1,000/mo</td>
                <td>Full coverage</td>
            </tr>
        </tbody>
    </table>
</div>
```

### Checklist Box (Blue)
```html
<div class="checklist-box">
    <h3>Checklist Title</h3>
    <ul>
        <li><strong>Item one</strong> - Description</li>
        <li><strong>Item two</strong> - Description</li>
    </ul>
</div>
```

### Info Card Grid
```html
<div class="strategy-section">
    <h2 class="section-title">Section Title</h2>
    <div class="card-grid">
        <div class="info-card">
            <h4>Card Title</h4>
            <p>Card description content.</p>
        </div>
        <!-- More cards... -->
    </div>
</div>
```

### Next Steps (CTA section)
```html
<div class="next-steps">
    <h2>Next Steps</h2>
    <ol>
        <li><strong>Step one</strong> - Description</li>
        <li><strong>Step two</strong> - Description</li>
    </ol>
</div>
```

## ScaledOn Brand Colors

```css
/* Primary Gradient */
background: linear-gradient(135deg, #f79253 0%, #ed4691 100%);

/* Footer Gradient */
background: linear-gradient(135deg, #3f56cd 0%, #ed4691 100%);

/* Accent Colors */
--scaledon-pink: #ed4691;
--scaledon-orange: #f79253;
--scaledon-blue: #3f56cd;

/* Status Colors */
--positive: #28a745 / #d4edda;
--negative: #dc3545 / #f8d7da;
--warning: #ffc107 / #fff3cd;
--info: #007bff / #e7f3ff;
```

## Image Guidelines

- Place images in `images/` subfolder
- Reference as `src="images/filename.png"`
- Screenshots with red borders use `.screenshot-container`
- Proof/results images use `.proof-section img`
