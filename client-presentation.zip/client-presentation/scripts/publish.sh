#!/bin/bash
# Publish a client presentation to GitHub/Cloudflare Pages
# Usage: ./publish.sh <client-slug> <source-folder>
#
# Example: ./publish.sh daphnis /path/to/presentation/folder
#
# The source folder should contain:
#   - index.html (the presentation)
#   - images/ (optional - any supporting images)

set -e

CLIENT_SLUG="$1"
SOURCE_FOLDER="$2"
REPO_PATH="/Users/domscaledon/Documents/GitHub Amazon Branch Nov/Amazon Dept/client-presentations"

if [ -z "$CLIENT_SLUG" ] || [ -z "$SOURCE_FOLDER" ]; then
    echo "Usage: ./publish.sh <client-slug> <source-folder>"
    echo "Example: ./publish.sh daphnis ./output/daphnis"
    exit 1
fi

# Validate source folder exists
if [ ! -d "$SOURCE_FOLDER" ]; then
    echo "Error: Source folder '$SOURCE_FOLDER' does not exist"
    exit 1
fi

# Validate index.html exists
if [ ! -f "$SOURCE_FOLDER/index.html" ]; then
    echo "Error: No index.html found in '$SOURCE_FOLDER'"
    exit 1
fi

echo "Publishing presentation for: $CLIENT_SLUG"
echo "Source: $SOURCE_FOLDER"
echo "Target: $REPO_PATH/$CLIENT_SLUG"

# Create target directory
mkdir -p "$REPO_PATH/$CLIENT_SLUG"

# Copy files
cp -r "$SOURCE_FOLDER"/* "$REPO_PATH/$CLIENT_SLUG/"

echo "Files copied successfully"

# Git operations
cd "$REPO_PATH"

# Unset GITHUB_TOKEN if set (conflicts with gh auth)
unset GITHUB_TOKEN

git add "$CLIENT_SLUG/"
git commit -m "Add/update $CLIENT_SLUG presentation"
git push

echo ""
echo "Published successfully!"
echo ""
echo "URL: https://scaledon-client-presentations.pages.dev/$CLIENT_SLUG/"
echo ""
echo "Credentials:"
echo "  Username: scaledon"
echo "  Password: daphnis2026"
